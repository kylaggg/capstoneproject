<?php $__env->startSection('title'); ?>
<h1>Appraisals Overview</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Immediate Superior</th>
                    <th>Internal Customer 1</th>
                    <th>Internal Customer 2</th>
                    <th>Status</th>
                    <th>Signatures</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maori\Desktop\capstoneproject\resources\views/admin-pages/admin_appraisals_overview.blade.php ENDPATH**/ ?>