<?php $__env->startSection('title'); ?>
<h1>Account Settings</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maori\Desktop\capstoneproject\resources\views/settings/settings.blade.php ENDPATH**/ ?>