<?php $__env->startSection('title'); ?>
    <h1>Appraisals Overview</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='d-flex gap-3'>
        <div class="content-container text-middle">
            <h4>School Year:</h4>
        </div>
        <div class="content-container text-middle">
            <h4>KRA Encoding:</h4>
        </div>
        <div class="content-container text-middle">
            <h4>Performance Review:</h4>
        </div>
        <div class="content-container text-middle">
            <h4>Evaluation:</h4>
        </div>
    </div>
    <div class="content-container">
        <table class='table'>
        <thead>
            <tr>
                <th>Self-Evaluation</th>
                <th>Internal Customer 1</th>
                <th>Internal Customer 2</th>
                <th>Immediate Superior</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <a href="<?php echo e(route('viewSelfEvaluationForm')); ?>" class="btn btn-outline-primary full-width" role="button">Self-Appraise</a>
                </td>
                <td>
                    <a href="#" class="btn btn-outline-primary full-width" role="button">View</a>
                </td>
                <td>
                    <a href="#" class="btn btn-outline-primary full-width" role="button">View</a>
                </td>
                <td>
                    <a href="#" class="btn btn-outline-primary full-width" role="button">View</a>
                </td>
            </tr>
        </tbody>
    </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maori\Desktop\capstoneproject\resources\views/pe-pages/pe_appraisals_overview.blade.php ENDPATH**/ ?>