@extends('layout.master')

@section('title')
<h1>Internal Customers Overview</h1>
@endsection

@section('content')
<div class="content-container">
    <table class='table'>
        <thead>
            <tr>
                <th>Name</th>
                <th>Department</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                
            </tr>
        </tbody>
    </table>
</div>
@endsection