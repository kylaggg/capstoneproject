<p>Your verification code is {{$verificationCode}}</p>
<p>Thank you.</p>