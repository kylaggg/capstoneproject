@extends('layout.master')

@section('title')
<h1>Dashboard</h1>
@endsection