@extends('layout.master')

@section('title')
<h1>Account Settings</h1>
@endsection
